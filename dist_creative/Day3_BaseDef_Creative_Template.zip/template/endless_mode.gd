extends Node

# ============================================================
#  FINAL CHALLENGE — ENDLESS MODE
#
#  The morning game had 8 waves and then stopped.  Endless mode
#  rips out the wave list and replaces it with infinite spawning
#  that gets harder over time.
#
#  Each of the 4 holes below is ALMOST EXACTLY something you
#  already wrote this morning, just reworded for endless mode.
#  You don't need any new ideas — only what's already in your
#  head.
#
#  Mirror map:
#      FC-1  ←  TODO #1  (declare a few state variables)
#      FC-2  ←  TODO #2a (append to enemies via spawn helper)
#      FC-3  ←  TODO #5a (write a function that returns ONE thing)
#      FC-4  ←  TODO #7  (size() check + escalation)
#
#  To switch the game into endless mode:
#    open `main.gd`, find `const ENDLESS_MODE := false`, and
#    change false → true.  Save, play.
# ============================================================

# This script gets attached to the Main node when ENDLESS_MODE is
# on (instructor wiring).  It calls into helpers already living
# in main.gd via @onready.
@onready var main: Node = get_parent()


# FC-1: Declare 5 top-level variables for endless mode state.
# Mirrors morning chunk #1 (variable declarations).
#
# Given:
#   - SPAWN_INTERVAL_START   — the starting spawn interval constant
#
# Syntax:
#   - var name: float = value