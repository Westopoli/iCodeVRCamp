extends Node2D

# ============================================================
#  DAY 3 — BASE DEFENSE
#
#  Today's tools: FUNCTIONS (deep — taking lists, returning
#  things) and LISTS (make them, add to them, scan them).
#
#  The game: enemies pour in from every edge of the field.
#  They want to wreck your base in the centre. You stop them
#  by placing TOWERS that shoot enemies (Cannon, Sniper,
#  Splash). Earn coins for each kill. Beat all 8 waves to win.
#
#  Controls:
#    1 / 2 / 3   pick tower type (or click the bottom buttons)
#    LMB         place selected tower on an empty grid cell
#    SPACE       start the next wave
#    R           restart
# ============================================================

# --- grid + viewport ---
const TILE := 40
const GRID_W := 32         # playfield columns (0..31)
const GRID_H := 17         # playfield rows    (0..16)  bottom 40 px = button bar
const SPRITE_SCALE := 0.625  # Kenney tiles are 64px -> scale to TILE

# --- base position (two cells, centre of the field) ---
const BASE_CELL_A := Vector2i(15, 8)
const BASE_CELL_B := Vector2i(16, 8)

# --- starting state ---
const START_COINS := 90
const START_BASE_HP := 22

# ============================================================
#  DIFFICULTY KNOB
#
#  One number. Scales enemy HP + per-wave HP bonus.
#  0 = easy (kids who struggle), 1 = normal, 2 = hard (top kids).
#  Try editing this and replaying — same code, different feel.
#  This is "lists indexed by state" — D3 concept in action.
# ============================================================
const DIFFICULTY := 2
const DIFF_HP_MULT := [0.7, 1.5, 3]        # enemy HP multiplier
const DIFF_WAVE_HP_BONUS := [0, 2, 4]        # extra HP per wave index on hard
const DIFF_NAME := ["EASY", "NORMAL", "HARD"]

# --- tower stats (TUNED via _balance/Day3 sim, iter 13 — see BIBLE D3 lock) ---
const TOWER_STATS := {
	"cannon": {"cost": 28, "range": 105.0, "fire_rate": 0.55, "damage": 3,  "hp": 30, "tile": 250, "color": Color(1.0, 0.6, 0.4)},
	"sniper": {"cost": 45, "range": 280.0, "fire_rate": 1.20, "damage": 16, "hp": 25, "tile": 251, "color": Color(0.6, 0.8, 1.0)},
	"splash": {"cost": 47, "range": 115.0, "fire_rate": 0.80, "damage": 5,  "hp": 40, "tile": 252, "color": Color(1.0, 0.9, 0.4)},
}

# --- enemy stats (TUNED) ---
const ENEMY_STATS := {
	"grunt":  {"hp": 18, "speed": 60.0,  "damage_to_base": 2, "tower_dps": 3.5, "reward": 4, "tile": 271, "color": Color(0.85, 0.85, 0.85)},
	"runner": {"hp": 7,  "speed": 115.0, "damage_to_base": 1, "tower_dps": 2.0, "reward": 3, "tile": 270, "color": Color(0.5, 1.0, 0.5)},
}

# --- wave list: each entry is [count, type] — pre-given tuning data ---
const WAVES := [
	[4,  "grunt"],
	[6,  "grunt"],
	[5,  "runner"],
	[8,  "grunt"],
	[8,  "runner"],
	[12, "grunt"],
	[10, "runner"],
	[18, "grunt"],
]

const SPAWN_INTERVAL := 0.7   # seconds between spawns within a wave

# Set to true to swap the wave list for the Final Challenge endless mode.
const ENDLESS_MODE := false

# Toggle this for an optional grid overlay (kids may like the visual).
const DRAW_GRID_LINES := true

# Whether enemy-enemy collision is "soft" (slide on each other).
# Already wired via Enemy.tscn collision_mask = 6 (layers 2 + 4 = enemies + towers).

# --- nodes wired in Main.tscn ---
@onready var base_node: Area2D = $Base
@onready var enemies_node: Node2D = $Enemies
@onready var towers_node: Node2D = $Towers
@onready var flash_layer: Node2D = $FlashLayer
@onready var wave_label: Label = $UI/TopBar/WaveLabel
@onready var coins_label: Label = $UI/TopBar/CoinsLabel
@onready var base_hp_label: Label = $UI/TopBar/BaseHPLabel
@onready var selected_label: Label = $UI/TopBar/SelectedLabel
@onready var hint_label: Label = $UI/ButtonBar/HintLabel
@onready var cannon_btn: Button = $UI/ButtonBar/CannonButton
@onready var sniper_btn: Button = $UI/ButtonBar/SniperButton
@onready var splash_btn: Button = $UI/ButtonBar/SplashButton
@onready var game_over_panel: Panel = $UI/GameOverPanel
@onready var you_win_panel: Panel = $UI/YouWinPanel

# --- preloads ---
const ENEMY_SCENE := preload("res://Enemy.tscn")

# TODO #1: Declare the four pieces of state the game needs to remember: an empty
# list of enemies, an empty list of towers, a coin counter starting at
# START_COINS (90), and a base-HP counter starting at START_BASE_HP (22).
# Without these, nothing else in the file compiles.
#
# Given:
#   - START_COINS      — starting coin constant
#   - START_BASE_HP    — starting base HP constant
#
# Syntax:
#   - var name: Array = []    (empty list)
#   - var name: int = value   (integer with type)